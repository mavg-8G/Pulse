import { useEffect } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import { AppShell } from './components/AppShell'
import { StepUpHost } from './components/StepUp'
import { useAuth } from './lib/auth'
import { useMe } from './lib/queries'
import { applyTheme } from './lib/theme'
import { Accounts } from './pages/Accounts'
import { EnrollPage, LoginPage, RegisterPage, VerifyPage } from './pages/AuthPages'
import { Categories } from './pages/Categories'
import { Home } from './pages/Home'
import { Movements } from './pages/Movements'
import { Plan } from './pages/Plan'
import { Settings } from './pages/Settings'

function Authenticated() {
  const { data: me } = useMe()
  useEffect(() => {
    if (me) applyTheme(me.theme)
  }, [me?.theme])
  return (
    <AppShell>
      <StepUpHost />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/movimientos" element={<Movements />} />
        <Route path="/plan" element={<Plan />} />
        <Route path="/ajustes" element={<Settings />} />
        <Route path="/ajustes/cuentas" element={<Accounts />} />
        <Route path="/ajustes/categorias" element={<Categories />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AppShell>
  )
}

export function App() {
  const { state } = useAuth()
  if (state === 'loading') return <p className="loading">Cargando…</p>
  if (state === 'mfa') return <VerifyPage />
  if (state === 'enroll') return <EnrollPage />
  if (state === 'none')
    return (
      <Routes>
        <Route path="/registro" element={<RegisterPage />} />
        <Route path="*" element={<LoginPage />} />
      </Routes>
    )
  return <Authenticated />
}
