import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import { NavLink, useSearchParams } from 'react-router-dom'
import { useMe } from '../lib/queries'
import type { Transaction } from '../lib/types'
import { IconHome, IconList, IconPlan, IconPlus, IconSettings, PulseMark } from './icons'
import { Sheet } from './Sheet'
import { TxForm } from './TxForm'

const TxSheetCtx = createContext<(tx?: Transaction) => void>(() => {})
export const useTxSheet = () => useContext(TxSheetCtx)

const nav = [
  { to: '/', label: 'Inicio', icon: <IconHome />, end: true },
  { to: '/movimientos', label: 'Movimientos', icon: <IconList /> },
  { to: '/plan', label: 'Plan', icon: <IconPlan /> },
  { to: '/ajustes', label: 'Ajustes', icon: <IconSettings /> },
]

export function AppShell({ children }: { children: ReactNode }) {
  const { data: me } = useMe()
  const [sheet, setSheet] = useState<{ open: boolean; tx?: Transaction }>({ open: false })
  const open = (tx?: Transaction) => setSheet({ open: true, tx })
  const [params, setParams] = useSearchParams()

  // Atajo del ícono instalado: /?nuevo=1 abre directo el formulario.
  useEffect(() => {
    if (params.get('nuevo') === '1') {
      open()
      params.delete('nuevo')
      setParams(params, { replace: true })
    }
  }, [params, setParams])

  return (
    <TxSheetCtx.Provider value={open}>
      <div className="shell">
        <nav className="sidebar" aria-label="Principal">
          <NavLink to="/" className="brand">
            <PulseMark />
            Pulse
          </NavLink>
          {nav.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} className="side-link">
              {n.icon}
              {n.label}
            </NavLink>
          ))}
          <button className="btn btn-primary side-add" onClick={() => open()}>
            <IconPlus /> Nuevo gasto
          </button>
          <p className="side-foot">{me?.email}</p>
        </nav>
        <main className="main" id="contenido">{children}</main>
        <nav className="tabbar" aria-label="Principal">
          {nav.slice(0, 2).map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} className="tab">
              {n.icon}
              {n.label}
            </NavLink>
          ))}
          <button className="tab-add" onClick={() => open()} aria-label="Nuevo gasto">
            <IconPlus />
          </button>
          {nav.slice(2).map((n) => (
            <NavLink key={n.to} to={n.to} className="tab">
              {n.icon}
              {n.label}
            </NavLink>
          ))}
        </nav>
      </div>
      <Sheet open={sheet.open} title={sheet.tx ? 'Editar gasto' : 'Nuevo gasto'} onClose={() => setSheet({ open: false })}>
        <TxForm key={sheet.tx?.id ?? 'new'} tx={sheet.tx} onDone={() => setSheet({ open: false })} />
      </Sheet>
    </TxSheetCtx.Provider>
  )
}

export function MonthSwitch({ month, onChange, label }: { month: string; onChange: (m: string) => void; label: string }) {
  return (
    <div className="month-switch" role="group" aria-label="Mes">
      <button className="icon-btn" aria-label="Mes anterior" onClick={() => onChange(shift(month, -1))}>
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true"><path d="m15 6-6 6 6 6" /></svg>
      </button>
      <strong aria-live="polite">{label}</strong>
      <button className="icon-btn" aria-label="Mes siguiente" onClick={() => onChange(shift(month, 1))}>
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true"><path d="m9 6 6 6-6 6" /></svg>
      </button>
    </div>
  )
}

function shift(month: string, d: number) {
  const [y, m] = month.split('-').map(Number)
  const t = new Date(Date.UTC(y, m - 1 + d, 1))
  return `${t.getUTCFullYear()}-${String(t.getUTCMonth() + 1).padStart(2, '0')}`
}
