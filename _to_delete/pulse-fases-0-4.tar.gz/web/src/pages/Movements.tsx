import { useState } from 'react'
import { MonthSwitch, useTxSheet } from '../components/AppShell'
import { TxGroups } from '../components/TxList'
import { monthLabel, monthOf } from '../lib/dates'
import { money } from '../lib/money'
import { useAccounts, useCategories, useMe, useTransactions } from '../lib/queries'

const PAGE = 50

export function Movements() {
  const { data: me } = useMe()
  const tz = me?.timezone ?? 'America/Guayaquil'
  const [month, setMonth] = useState(monthOf(new Date(), tz))
  const [q, setQ] = useState('')
  const [category, setCategory] = useState('')
  const [account, setAccount] = useState('')
  const [limit, setLimit] = useState(PAGE)
  const { data: categories = [] } = useCategories()
  const { data: accounts = [] } = useAccounts(true)
  const { data, isLoading, error } = useTransactions({ month, q: q.trim(), category_id: category, account_id: account, limit })
  const openTx = useTxSheet()
  const tops = categories.filter((c) => !c.parent_id)
  const filtered = q.trim() !== '' || category !== '' || account !== ''

  return (
    <>
      <div className="page-head">
        <h1>Movimientos</h1>
        <MonthSwitch month={month} onChange={(m) => { setMonth(m); setLimit(PAGE) }} label={monthLabel(month)} />
      </div>
      <div className="filters">
        <input className="input search" type="search" placeholder="Buscar comercio o nota" aria-label="Buscar" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="select" aria-label="Categoría" value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">Todas las categorías</option>
          {tops.map((c) => (
            <option key={c.id} value={c.id}>{c.icon} {c.name}</option>
          ))}
        </select>
        <select className="select" aria-label="Cuenta" value={account} onChange={(e) => setAccount(e.target.value)}>
          <option value="">Todas las cuentas</option>
          {accounts.map((a) => (
            <option key={a.id} value={a.id}>{a.name}</option>
          ))}
        </select>
      </div>
      {data && data.total > 0 && (
        <p className="totals-line">
          <span>{data.total} {data.total === 1 ? 'movimiento' : 'movimientos'}</span>
          <strong className="num" data-testid="list-sum">{money(data.sum_cents)}</strong>
        </p>
      )}
      {isLoading && <p className="loading">Cargando…</p>}
      {error && <p className="error" role="alert">No se pudieron cargar los movimientos.</p>}
      {data && data.total === 0 && (
        <div className="panel empty" style={{ marginTop: 16 }}>
          {filtered ? (
            <>
              <h3>Nada coincide con esos filtros</h3>
              <p>Prueba con otra palabra u otro mes.</p>
            </>
          ) : (
            <>
              <h3>Sin movimientos en {monthLabel(month).toLowerCase()}</h3>
              <button className="btn btn-primary" onClick={() => openTx()}>Registrar gasto</button>
            </>
          )}
        </div>
      )}
      {data && <TxGroups items={data.items} categories={categories} accounts={accounts} tz={tz} />}
      {data && data.items.length < data.total && (
        <button className="btn btn-block" style={{ marginTop: 16 }} onClick={() => setLimit(limit + PAGE)}>
          Mostrar más
        </button>
      )}
    </>
  )
}
