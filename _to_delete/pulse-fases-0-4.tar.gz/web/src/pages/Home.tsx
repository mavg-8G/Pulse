import { useState } from 'react'
import { Link } from 'react-router-dom'
import { MonthSwitch, useTxSheet } from '../components/AppShell'
import { PulseTrace } from '../components/PulseTrace'
import { TxGroups } from '../components/TxList'
import { monthLabel, monthOf } from '../lib/dates'
import { money } from '../lib/money'
import { useAccounts, useCategories, useDashboard, useMe } from '../lib/queries'
import type { Alert } from '../lib/types'

// Un aviso por presupuesto: el umbral más alto alcanzado.
function topAlerts(alerts: Alert[]) {
  const best = new Map<string, Alert>()
  for (const a of alerts) if ((best.get(a.budget_id)?.threshold ?? 0) < a.threshold) best.set(a.budget_id, a)
  return [...best.values()].sort((a, b) => b.threshold - a.threshold).slice(0, 3)
}

export function Home() {
  const { data: me } = useMe()
  const tz = me?.timezone ?? 'America/Guayaquil'
  const current = monthOf(new Date(), tz)
  const [month, setMonth] = useState(current)
  const { data: d, isLoading, error } = useDashboard(month)
  const { data: categories = [] } = useCategories()
  const { data: accounts = [] } = useAccounts(true)
  const openTx = useTxSheet()

  const isCurrent = month === current
  const today = isCurrent ? Number(new Intl.DateTimeFormat('en-CA', { timeZone: tz, day: 'numeric' }).format(new Date())) : null
  const cats = new Map(categories.map((c) => [c.id, c]))
  const label = monthLabel(month)

  return (
    <>
      <div className="page-head">
        <h1>Inicio</h1>
        <MonthSwitch month={month} onChange={setMonth} label={label} />
      </div>

      {isLoading && <p className="loading">Cargando…</p>}
      {error && <p className="error" role="alert">No se pudo cargar el resumen. Revisa tu conexión.</p>}
      {d && (
        <>
          <section aria-label="Gastado en el mes">
            <p className="hero-amount" data-testid="month-total">{money(d.spent_cents)}</p>
            <p className="hero-sub">
              {d.count === 0
                ? `Sin gastos en ${label.toLowerCase()}.`
                : `${d.count} ${d.count === 1 ? 'movimiento' : 'movimientos'} en ${label.toLowerCase()}`}
            </p>
            <PulseTrace daily={d.daily_cents} today={today} />
          </section>

          {d.has_budgets && (
            <Link to="/plan" className="plan-strip">
              <span className="muted small">Plan del mes</span>
              <span>
                <strong className="num">{money(d.budget.spent_cents)}</strong> de <span className="num">{money(d.budget.budget_cents)}</span>
              </span>
              {d.budget.remaining_cents >= 0 ? (
                <span className="muted small">Te quedan {money(d.budget.remaining_cents)}.</span>
              ) : (
                <span className="st-over small">Te pasaste por {money(-d.budget.remaining_cents)}.</span>
              )}
              {isCurrent && d.budget.projected_over_cents > 0 && (
                <span className="st-warning small">A este ritmo cerrarás el mes en {money(d.budget.projected_cents)}.</span>
              )}
            </Link>
          )}

          {d.alerts.length > 0 && (
            <div className="section stack" aria-label="Avisos del plan">
              {topAlerts(d.alerts).map((a) => {
                const c = cats.get(a.category_id)
                return (
                  <div key={`${a.budget_id}-${a.threshold}`} className={`notice ${a.threshold >= 100 ? 'over' : ''}`}>
                    <span aria-hidden="true">{c?.icon}</span>
                    <span>
                      {a.threshold >= 100 ? 'Llegaste al tope de ' : `Llevas el ${a.threshold}% de `}
                      <strong>{c?.name}</strong>.
                    </span>
                  </div>
                )
              })}
            </div>
          )}

          {d.by_category.length > 0 && (
            <section className="section" aria-labelledby="h-cat">
              <div className="section-head">
                <h2 id="h-cat">En qué se fue</h2>
              </div>
              <div className="panel bars">
                {d.by_category.slice(0, 6).map((c) => {
                  const pct = d.spent_cents > 0 ? Math.max(2, Math.round((c.spent_cents / d.spent_cents) * 100)) : 0
                  return (
                    <div className="bar-row" key={c.category_id}>
                      <span>
                        <span aria-hidden="true">{c.icon}</span> {c.name}
                      </span>
                      <span className="num">{money(c.spent_cents)}</span>
                      <div className="track" aria-hidden="true">
                        <div className="fill" style={{ width: `${pct}%`, background: c.color }} />
                      </div>
                    </div>
                  )
                })}
              </div>
            </section>
          )}

          <section className="section" aria-labelledby="h-recent">
            <div className="section-head">
              <h2 id="h-recent">Últimos movimientos</h2>
              {d.recent.length > 0 && <Link to="/movimientos">Ver todos</Link>}
            </div>
            {d.recent.length === 0 ? (
              <div className="panel empty">
                <h3>Todavía no hay gastos este mes</h3>
                <p>Registra el primero y empieza a ver tu pulso.</p>
                <button className="btn btn-primary" onClick={() => openTx()}>Registrar gasto</button>
              </div>
            ) : (
              <TxGroups items={d.recent} categories={categories} accounts={accounts} tz={tz} />
            )}
          </section>
        </>
      )}
    </>
  )
}
