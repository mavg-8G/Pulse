// Package config carga y valida la configuración desde variables de entorno.
// Falla rápido: si algo falta o es inválido, el proceso no arranca.
package config

import (
	"errors"
	"fmt"
	"net"
	"net/url"
	"strconv"
	"strings"
	"time"
	_ "time/tzdata" // zona horaria embebida: la imagen no depende del sistema
)

type Config struct {
	Env            string // production | development | test
	BaseURL        *url.URL
	Listen         string
	DBPath         string
	KEKFile        string
	TrustedProxies []*net.IPNet
	DefaultTZ      string
	// RegisterPerHour limita los intentos de registro por IP. Solo se sube para los tests E2E.
	RegisterPerHour int
}

func (c *Config) Production() bool { return c.Env == "production" }

// Origin devuelve "https://host[:puerto]" sin barra final.
func (c *Config) Origin() string { return c.BaseURL.Scheme + "://" + c.BaseURL.Host }

// RPID es el identificador WebAuthn (el host sin puerto).
func (c *Config) RPID() string { return c.BaseURL.Hostname() }

// Load lee la configuración. getenv suele ser os.Getenv; los tests pasan un mapa.
func Load(getenv func(string) string) (*Config, error) {
	get := func(k, def string) string {
		if v := strings.TrimSpace(getenv(k)); v != "" {
			return v
		}
		return def
	}
	var errs []error
	c := &Config{
		Env:       get("PULSE_ENV", "production"),
		Listen:    get("PULSE_LISTEN", ":8080"),
		DBPath:    get("PULSE_DB_PATH", "/data/pulse.db"),
		KEKFile:   get("PULSE_KEK_FILE", "/run/secrets/pulse_kek"),
		DefaultTZ: get("TZ", "America/Guayaquil"),
	}
	c.RegisterPerHour = 5
	if v := get("PULSE_REGISTER_PER_HOUR", ""); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 || n > 10000 {
			errs = append(errs, fmt.Errorf("PULSE_REGISTER_PER_HOUR inválido: %q", v))
		} else if c.Env == "production" && n > 20 {
			errs = append(errs, errors.New("PULSE_REGISTER_PER_HOUR no puede pasar de 20 en producción"))
		} else {
			c.RegisterPerHour = n
		}
	}
	switch c.Env {
	case "production", "development", "test":
	default:
		errs = append(errs, fmt.Errorf("PULSE_ENV inválido %q (production|development|test)", c.Env))
	}

	raw := get("PULSE_BASE_URL", "")
	if raw == "" {
		errs = append(errs, errors.New("PULSE_BASE_URL es obligatorio (ej. https://pulse.espectro.uk)"))
	} else if u, err := url.Parse(raw); err != nil || u.Host == "" || (u.Scheme != "https" && u.Scheme != "http") {
		errs = append(errs, fmt.Errorf("PULSE_BASE_URL inválido: %q", raw))
	} else {
		if u.Scheme != "https" && c.Env == "production" {
			errs = append(errs, errors.New("PULSE_BASE_URL debe usar https en producción"))
		}
		if u.Path != "" && u.Path != "/" {
			errs = append(errs, errors.New("PULSE_BASE_URL no debe tener ruta"))
		}
		u.Path = ""
		c.BaseURL = u
	}

	if _, err := time.LoadLocation(c.DefaultTZ); err != nil {
		errs = append(errs, fmt.Errorf("TZ inválida %q", c.DefaultTZ))
	}

	for _, cidr := range strings.Split(get("PULSE_TRUSTED_PROXY", ""), ",") {
		cidr = strings.TrimSpace(cidr)
		if cidr == "" {
			continue
		}
		_, n, err := net.ParseCIDR(cidr)
		if err != nil {
			errs = append(errs, fmt.Errorf("PULSE_TRUSTED_PROXY inválido: %q", cidr))
			continue
		}
		c.TrustedProxies = append(c.TrustedProxies, n)
	}
	if err := errors.Join(errs...); err != nil {
		return nil, err
	}
	return c, nil
}
