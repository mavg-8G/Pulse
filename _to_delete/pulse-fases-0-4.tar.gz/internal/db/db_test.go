package db

import (
	"context"
	"path/filepath"
	"testing"
)

func open(t *testing.T) *DBT {
	t.Helper()
	d, err := Open(filepath.Join(t.TempDir(), "t.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { d.Close() })
	return &DBT{d}
}

func TestMigracionesSubenYBajan(t *testing.T) {
	ctx := context.Background()
	d := open(t)
	ms, err := loadMigrations()
	if err != nil {
		t.Fatal(err)
	}
	if err := Migrate(ctx, d.DB); err != nil {
		t.Fatal(err)
	}
	if v, _ := Version(ctx, d.DB); v != len(ms) {
		t.Fatalf("versión %d, esperaba %d", v, len(ms))
	}
	// Idempotente
	if err := Migrate(ctx, d.DB); err != nil {
		t.Fatal(err)
	}
	if err := MigrateDown(ctx, d.DB, 0); err != nil {
		t.Fatal(err)
	}
	var n int
	d.QueryRow(`SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name NOT IN ('schema_migrations','sqlite_sequence')`).Scan(&n)
	if n != 0 {
		t.Fatalf("quedaron %d tablas tras revertir todo", n)
	}
	// Y vuelven a subir limpias
	if err := Migrate(ctx, d.DB); err != nil {
		t.Fatal(err)
	}
}

func TestPragmasDeSeguridad(t *testing.T) {
	d := open(t)
	checks := map[string]string{"foreign_keys": "1", "journal_mode": "wal", "secure_delete": "1"}
	for p, want := range checks {
		var got string
		if err := d.QueryRow("PRAGMA " + p).Scan(&got); err != nil {
			t.Fatal(err)
		}
		if got != want {
			t.Errorf("PRAGMA %s = %s, esperaba %s", p, got, want)
		}
	}
}

func TestAuditLogEsSoloInsercion(t *testing.T) {
	ctx := context.Background()
	d := open(t)
	if err := Migrate(ctx, d.DB); err != nil {
		t.Fatal(err)
	}
	if _, err := d.Exec(`INSERT INTO audit_log (event, created_at) VALUES ('x', 'now')`); err != nil {
		t.Fatal(err)
	}
	if _, err := d.Exec(`UPDATE audit_log SET event = 'y'`); err == nil {
		t.Fatal("UPDATE sobre audit_log debería fallar")
	}
	if _, err := d.Exec(`DELETE FROM audit_log`); err == nil {
		t.Fatal("DELETE sobre audit_log debería fallar")
	}
}

func TestVersionFuturaRechazada(t *testing.T) {
	ctx := context.Background()
	d := open(t)
	if err := Migrate(ctx, d.DB); err != nil {
		t.Fatal(err)
	}
	d.Exec(`INSERT INTO schema_migrations VALUES (999, 'futura', 'x')`)
	if err := Migrate(ctx, d.DB); err == nil {
		t.Fatal("debe negarse a correr sobre un esquema más nuevo")
	}
}
